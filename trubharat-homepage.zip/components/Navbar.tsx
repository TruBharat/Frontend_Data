import React from 'react';
import { Search, ShoppingBag, Heart, User, Sun, Moon, Menu } from 'lucide-react';
import { PageView } from '../types';

interface NavbarProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
  cartCount: number;
  wishlistCount: number;
  setPageView: (view: PageView) => void;
}

const Logo = () => (
  <div className="flex items-center gap-3 cursor-pointer group">
    <div className="relative w-10 h-10">
      {/* TruBharat Golden Leaf/Spade Logo approximation */}
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-md group-hover:scale-110 transition-transform duration-300">
        <path d="M50 15 C30 15 10 35 10 60 C10 85 50 100 50 100 C50 100 90 85 90 60 C90 35 70 15 50 15" fill="none" stroke="#dba11c" strokeWidth="3" />
        <path d="M50 25 C50 25 30 40 30 55 C30 70 45 75 50 65 C55 75 70 70 70 55 C70 40 50 25 50 25" fill="none" stroke="#dba11c" strokeWidth="3" />
        <path d="M50 65 V 85" stroke="#dba11c" strokeWidth="3" />
        <path d="M30 55 Q 20 55 25 70" fill="none" stroke="#dba11c" strokeWidth="3" />
        <path d="M70 55 Q 80 55 75 70" fill="none" stroke="#dba11c" strokeWidth="3" />
        <circle cx="50" cy="50" r="2" fill="#dba11c" />
      </svg>
    </div>
    <div className="flex flex-col">
      <span className="text-2xl font-display font-bold text-slate-900 dark:text-white tracking-widest leading-none">
        TRUBHARAT
      </span>
    </div>
  </div>
);

export const Navbar: React.FC<NavbarProps> = ({ darkMode, toggleDarkMode, cartCount, wishlistCount, setPageView }) => {
  return (
    <nav className="sticky top-0 z-50 w-full backdrop-blur-xl bg-white/90 dark:bg-slate-950/90 border-b border-orange-100 dark:border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          <div onClick={() => setPageView(PageView.HOME)}>
            <Logo />
          </div>

          <div className="hidden md:flex flex-1 max-w-lg mx-8 relative">
            <input
              type="text"
              placeholder="Search for Indian brands..."
              className="w-full pl-10 pr-4 py-2.5 rounded-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:border-orange-500 focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-orange-500/10 text-sm transition-all text-slate-900 dark:text-white placeholder-slate-400"
            />
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <button 
                onClick={() => setPageView(PageView.SHOP)}
                className="hidden md:block px-4 py-2 text-sm font-bold text-slate-600 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50 dark:hover:bg-slate-800 rounded-full transition-all"
            >
                Categories
            </button>
            
            <button 
              onClick={toggleDarkMode} 
              className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-all hover:scale-105"
            >
              {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>

            <button 
              onClick={() => setPageView(PageView.WISHLIST)}
              className="relative p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-all hover:scale-105"
            >
              <Heart className="w-5 h-5 hover:text-red-500 transition-colors" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] flex items-center justify-center rounded-full font-bold shadow-sm">
                  {wishlistCount}
                </span>
              )}
            </button>

            <button className="relative p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-all hover:scale-105">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-orange-600 text-white text-[10px] flex items-center justify-center rounded-full font-bold shadow-sm">
                  {cartCount}
                </span>
              )}
            </button>

             <button className="hidden sm:block p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-all">
              <User className="w-5 h-5" />
            </button>
            
            <button className="md:hidden p-2">
                <Menu className="w-6 h-6 text-slate-700 dark:text-slate-300" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};