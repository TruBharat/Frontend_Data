import React from 'react';

export const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="space-y-4">
          <h3 className="text-2xl font-display font-bold text-white">TRUBHARAT</h3>
          <p className="text-sm leading-relaxed">
            Supporting the vision of Atmanirbhar Bharat. A curated marketplace for premium and emerging Indian brands.
          </p>
        </div>
        
        <div>
          <h4 className="font-bold text-white mb-4">Shop</h4>
          <ul className="space-y-2 text-sm">
            <li>Men's Fashion</li>
            <li>Women's Ethnic</li>
            <li>Tech & Gadgets</li>
            <li>Home Decor</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-4">Support</h4>
          <ul className="space-y-2 text-sm">
            <li>Track Order</li>
            <li>Returns & Refunds</li>
            <li>Partner with Us</li>
            <li>Contact Support</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-4">Newsletter</h4>
          <div className="flex gap-2">
            <input type="email" placeholder="Email Address" className="bg-slate-800 border-none rounded-lg px-4 py-2 text-sm w-full" />
            <button className="bg-orange-600 text-white px-4 py-2 rounded-lg font-bold">Go</button>
          </div>
        </div>
      </div>
      <div className="text-center mt-12 pt-8 border-t border-slate-800 text-xs">
        © 2024 TruBharat. Made with ❤️ in India.
      </div>
    </footer>
  );
};