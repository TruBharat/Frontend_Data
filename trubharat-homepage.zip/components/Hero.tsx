import React from 'react';
import { ArrowRight } from 'lucide-react';
import { PageView } from '../types';

interface HeroProps {
  setPageView: (view: PageView) => void;
}

export const Hero: React.FC<HeroProps> = ({ setPageView }) => {
  return (
    <section className="relative overflow-hidden bg-slate-50 dark:bg-slate-950 pt-12 pb-16 px-4 sm:px-6 lg:px-8 transition-colors duration-300 border-b border-orange-100 dark:border-slate-800">
      
      {/* Background Ambience */}
      <div className="absolute top-0 right-0 w-[60%] h-full bg-gradient-to-l from-orange-100/40 to-transparent dark:from-orange-900/10 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Text Content */}
          <div className="space-y-6 relative z-10 text-center lg:text-left">
            <h1 className="text-5xl sm:text-6xl md:text-7xl font-display font-bold leading-[1.05] text-slate-900 dark:text-white">
              India's Biggest <br />
              <span className="text-slate-900 dark:text-white">All-Indian Brand</span> <br/>
              <span className="text-slate-900 dark:text-white">Marketplace</span>
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 dark:text-slate-300 font-medium max-w-lg mx-auto lg:mx-0">
              Premium – Budget – Startup – <br/>
              Everything Made in India, <span className="text-slate-900 dark:text-white font-bold">In One Place.</span>
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
              <button 
                onClick={() => setPageView(PageView.SHOP)}
                className="px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold shadow-lg shadow-orange-500/30 transition-all hover:-translate-y-1"
              >
                Explore Indian Brands
              </button>
              <button 
                onClick={() => setPageView(PageView.SHOP)}
                className="px-8 py-4 bg-[#1e3a4c] hover:bg-[#2c4b5f] text-white border border-[#1e3a4c] rounded-xl font-bold transition-all hover:-translate-y-1"
              >
                 Support Made in India
              </button>
            </div>
          </div>

          {/* Hero Illustration */}
          <div className="relative mt-8 lg:mt-0 flex justify-center lg:justify-end">
             <img 
               src="https://images.unsplash.com/photo-1540221652346-e5dd6b50f3e7?auto=format&fit=crop&q=80&w=800"
               alt="Shopping in India" 
               className="w-full max-w-lg object-contain drop-shadow-2xl rounded-[3rem]"
             />
             {/* Note: In a real scenario, this would be the specific illustration from the prompt. 
                 Using a high-quality placeholder that fits the vibe. */}
          </div>
        </div>
      </div>
    </section>
  );
};