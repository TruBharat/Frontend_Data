
import React from 'react';
import { ShoppingBag, Laptop, Home, Sparkles, Apple, Rocket, ArrowRight, CheckCircle } from 'lucide-react';
import { CATEGORIES, BRANDS, PRODUCTS } from '../constants';
import { PageView } from '../types';

const IconMap: Record<string, any> = {
    'shirt': ShoppingBag,
    'headphones': Laptop,
    'home': Home,
    'sparkles': Sparkles,
    'apple': Apple,
    'rocket': Rocket
}

interface FeaturesProps {
    setPageView: (view: PageView) => void;
}

export const Features: React.FC<FeaturesProps> = ({ setPageView }) => {
  const featuredBrands = PRODUCTS.slice(0, 4); // Maps to FabIndia, boAt, Mamaearth, Noise
  const trendingDeals = PRODUCTS.filter(p => p.id.startsWith('trending'));

  return (
    <div className="space-y-16 pb-20 bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      
      {/* 1. Featured Brands Scrolling Container (Marquee) */}
      <section className="bg-white dark:bg-slate-900 border-y border-slate-100 dark:border-slate-800 py-8 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 mb-6">
            <h2 className="text-lg font-bold text-slate-500 uppercase tracking-widest text-center">Trusted By India's Best</h2>
        </div>
        
        <div className="relative w-full overflow-hidden group">
             {/* Gradient Masks */}
             <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-white dark:from-slate-900 to-transparent z-10"></div>
             <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-white dark:from-slate-900 to-transparent z-10"></div>
             
             <div className="flex animate-marquee gap-8 items-center w-max px-4">
                {[...BRANDS, ...BRANDS].map((brand, idx) => (
                    <div 
                        key={`${brand.id}-${idx}`} 
                        className="w-32 h-20 sm:w-40 sm:h-24 bg-white rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center p-4 hover:shadow-lg transition-all cursor-pointer hover:scale-105"
                    >
                        {/* We use bg-white on the card itself even in dark mode to preserve logo colors, or styling the image */}
                        <img 
                            src={brand.logo} 
                            alt={brand.name} 
                            className="max-h-12 max-w-full object-contain"
                            onError={(e) => {
                                (e.target as HTMLImageElement).style.display = 'none';
                                ((e.target as HTMLImageElement).parentNode as HTMLElement).innerText = brand.name;
                            }}
                        />
                    </div>
                ))}
             </div>
        </div>
      </section>

      {/* 2. Shop By Category (Rounded Squares) */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4 sm:gap-6">
            {CATEGORIES.map((cat) => {
                const Icon = IconMap[cat.icon];
                return (
                    <div 
                        key={cat.id} 
                        onClick={() => setPageView(PageView.SHOP)}
                        className="group flex flex-col items-center gap-4 cursor-pointer"
                    >
                        <div className="w-full aspect-square bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 group-hover:border-orange-200 group-hover:shadow-lg flex items-center justify-center transition-all duration-300">
                            <Icon className="w-8 h-8 sm:w-10 sm:h-10 text-slate-700 dark:text-orange-400 group-hover:scale-110 group-hover:text-orange-600 transition-all" />
                        </div>
                        <span className="text-sm sm:text-base font-bold text-slate-700 dark:text-slate-300 text-center leading-tight">
                            {cat.name.split(' ').map((word, i) => <React.Fragment key={i}>{word}<br/></React.Fragment>)}
                        </span>
                    </div>
                )
            })}
        </div>
      </section>

      {/* 3. Featured Indian Brands (Specific Card Layout) */}
      <section className="max-w-7xl mx-auto px-4">
         <div className="flex justify-between items-end mb-8">
            <div>
                <h2 className="text-3xl font-display font-bold text-slate-900 dark:text-white">Featured Indian Brands</h2>
                <p className="text-slate-500 mt-1">New Startups • New India</p>
            </div>
            <button onClick={() => setPageView(PageView.SHOP)} className="text-slate-600 hover:text-orange-600 font-bold flex items-center gap-1">
                See All <ArrowRight className="w-4 h-4" />
            </button>
         </div>

         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredBrands.map((product, idx) => {
                const brand = BRANDS.find(b => b.name === product.brand) || BRANDS[0];
                const cardBgColors = ['bg-orange-50', 'bg-blue-50', 'bg-green-50', 'bg-purple-50']; // Subtle backgrounds for variety
                const darkCardBgColors = ['dark:bg-orange-900/10', 'dark:bg-blue-900/10', 'dark:bg-green-900/10', 'dark:bg-purple-900/10'];

                return (
                    <div key={product.id} className={`bg-white dark:bg-slate-900 rounded-[1.5rem] p-6 border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden`}>
                        {/* Background Splash */}
                        <div className={`absolute top-0 left-0 w-full h-24 opacity-30 ${cardBgColors[idx % 4]} ${darkCardBgColors[idx % 4]}`}></div>

                        {/* Brand Logo & Info */}
                        <div className="relative z-10 mb-4 flex flex-col items-center">
                             <div className="h-12 w-24 mb-2 flex items-center justify-center">
                                <img src={brand.logo} alt={brand.name} className="max-h-full max-w-full object-contain" />
                             </div>
                             <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Founded {brand.founded}</p>
                        </div>

                        {/* Verified Badge */}
                        <div className="relative z-10 flex items-center gap-1.5 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 px-3 py-1 rounded-full mb-6 shadow-sm">
                            <CheckCircle className="w-3 h-3 text-green-500 fill-green-500 text-white" />
                            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300">Verified Indian Brand</span>
                        </div>

                        {/* Product Content */}
                        <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-1 line-clamp-1">{product.name}</h3>
                        <p className="text-xs text-slate-400 mb-6 line-clamp-2 px-2">Premium quality {product.category.toLowerCase()} directly from {brand.name}</p>
                        
                        <button 
                            onClick={() => setPageView(PageView.SHOP)}
                            className={`w-full py-3 rounded-xl font-bold text-white shadow-lg transition-transform active:scale-95 ${idx % 2 === 0 ? 'bg-orange-500 hover:bg-orange-600 shadow-orange-500/20' : 'bg-[#0f766e] hover:bg-[#0d9488] shadow-teal-500/20'}`}
                        >
                            {idx % 2 === 0 ? 'Shop Now' : 'Add to Cart'}
                        </button>
                    </div>
                );
            })}
         </div>
      </section>

      {/* 4. Trending Deals (Horizontal Cards) */}
      <section className="max-w-7xl mx-auto px-4">
         <h2 className="text-3xl font-display font-bold text-slate-900 dark:text-white mb-8">Trending Deals</h2>
         
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {trendingDeals.map((deal) => (
                <div key={deal.id} className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4 hover:shadow-md transition-shadow group cursor-pointer">
                    <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-xl overflow-hidden flex-shrink-0 relative">
                        <img src={deal.image} alt={deal.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-900" />
                        <div className="absolute top-0 left-0 bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded-br-lg shadow-sm">
                            15% OFF
                        </div>
                    </div>
                    <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-slate-900 dark:text-white mb-1 truncate">{deal.name}</h4>
                        <div className="flex items-center justify-between mt-2">
                             <div>
                                <span className="font-bold text-lg text-slate-900 dark:text-white">₹{deal.price}</span>
                                <span className="text-xs text-slate-400 line-through ml-2">₹{Math.floor(deal.price * 1.15)}</span>
                             </div>
                             <button 
                                onClick={() => setPageView(PageView.SHOP)}
                                className="bg-[#0f766e] text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-[#0d9488] transition-colors"
                             >
                                Add
                             </button>
                        </div>
                    </div>
                </div>
            ))}
         </div>
      </section>

      {/* 5. Why TruBharat? (Bottom Section) */}
      <section className="mt-8 mx-4">
         <div className="max-w-7xl mx-auto">
            <h2 className="text-2xl font-display font-bold text-slate-900 dark:text-white mb-8">Why TruBharat?</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                    { title: "100% Indian Brands Only", icon: "🇮🇳", bg: "bg-blue-50 dark:bg-blue-900/20" },
                    { title: "Premium to Budget", icon: "💎", bg: "bg-orange-50 dark:bg-orange-900/20" },
                    { title: "Zero Fake Products", icon: "🛡️", bg: "bg-green-50 dark:bg-green-900/20" },
                    { title: "Direct Collaboration", icon: "🤝", bg: "bg-purple-50 dark:bg-purple-900/20" }
                ].map((item, i) => (
                    <div key={i} className={`${item.bg} border border-slate-100 dark:border-slate-800 rounded-2xl p-6 flex flex-col items-center text-center gap-3 hover:scale-105 transition-transform`}>
                        <div className="text-3xl mb-2">{item.icon}</div>
                        <h3 className="text-slate-900 dark:text-white font-bold text-sm leading-tight">{item.title}</h3>
                    </div>
                ))}
            </div>
         </div>
      </section>

    </div>
  );
};
