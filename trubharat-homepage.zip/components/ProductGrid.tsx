import React, { useState } from 'react';
import { Heart, SlidersHorizontal, ChevronDown, ShoppingCart } from 'lucide-react';
import { PRODUCTS, CATEGORIES } from '../constants';
import { Product } from '../types';

interface ProductGridProps {
  addToCart: (product: Product) => void;
  addToWishlist: (product: Product) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({ addToCart, addToWishlist }) => {
  const [priceRange, setPriceRange] = useState(10000);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const filteredProducts = PRODUCTS.filter(p => 
    (selectedCategory === 'All' || p.category === selectedCategory) &&
    p.price <= priceRange
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Breadcrumb & Header */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
        <div>
            <div className="text-sm text-slate-500 mb-2">Home / Clothing / Ethnic</div>
            <h2 className="text-3xl font-display font-bold text-slate-900 dark:text-white">Shop Indian Brands</h2>
            <p className="text-slate-500">Showing 1–{filteredProducts.length} of {PRODUCTS.length} products</p>
        </div>
        <div className="flex items-center gap-3">
             <div className="relative">
                <select className="appearance-none bg-slate-100 dark:bg-slate-800 border-none rounded-xl py-3 pl-4 pr-10 text-sm font-medium focus:ring-2 focus:ring-orange-500">
                    <option>Sort by: Popularity</option>
                    <option>Price: Low to High</option>
                    <option>Newest First</option>
                </select>
                <ChevronDown className="w-4 h-4 absolute right-3 top-3.5 text-slate-500 pointer-events-none" />
             </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Sidebar Filters */}
        <aside className="lg:col-span-1 space-y-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 sticky top-24">
            <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-lg dark:text-white">Filters</h3>
                <SlidersHorizontal className="w-5 h-5 text-slate-400" />
            </div>

            {/* Price Slider */}
            <div className="mb-8">
                <h4 className="font-medium mb-4 text-sm uppercase tracking-wider text-slate-500">Price Range</h4>
                <input 
                    type="range" 
                    min="0" 
                    max="15000" 
                    value={priceRange} 
                    onChange={(e) => setPriceRange(Number(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-orange-600"
                />
                <div className="flex justify-between mt-2 text-sm font-medium dark:text-slate-300">
                    <span>₹0</span>
                    <span>₹{priceRange.toLocaleString()}</span>
                </div>
            </div>

            {/* Categories */}
            <div className="mb-8">
                <h4 className="font-medium mb-4 text-sm uppercase tracking-wider text-slate-500">Categories</h4>
                <div className="space-y-3">
                    {['All', ...CATEGORIES.map(c => c.name)].map((cat) => (
                        <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                            <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${selectedCategory === cat ? 'bg-orange-600 border-orange-600' : 'border-slate-300 dark:border-slate-600'}`}>
                                {selectedCategory === cat && <div className="w-2 h-2 bg-white rounded-full" />}
                            </div>
                            <input 
                                type="radio" 
                                name="category" 
                                className="hidden" 
                                checked={selectedCategory === cat}
                                onChange={() => setSelectedCategory(cat)}
                            />
                            <span className={`text-sm ${selectedCategory === cat ? 'font-bold text-orange-600' : 'text-slate-600 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white'}`}>
                                {cat}
                            </span>
                        </label>
                    ))}
                </div>
            </div>

            {/* Colors (Mock) */}
             <div>
                <h4 className="font-medium mb-4 text-sm uppercase tracking-wider text-slate-500">Color</h4>
                <div className="flex gap-2 flex-wrap">
                    {['bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-black', 'bg-white border'].map((color, i) => (
                        <div key={i} className={`w-8 h-8 rounded-full ${color} cursor-pointer hover:scale-110 transition-transform shadow-sm`}></div>
                    ))}
                </div>
            </div>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="lg:col-span-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                    <div key={product.id} className="group bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 overflow-hidden hover:shadow-2xl hover:shadow-orange-500/10 transition-all duration-500 flex flex-col">
                        <div className="relative aspect-[4/5] overflow-hidden">
                            <img 
                                src={product.image} 
                                alt={product.name} 
                                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                            />
                            <button 
                                onClick={() => addToWishlist(product)}
                                className="absolute top-4 right-4 p-2 bg-white/80 dark:bg-slate-900/80 backdrop-blur rounded-full hover:bg-red-50 dark:hover:bg-red-900/30 text-slate-600 dark:text-slate-300 hover:text-red-500 transition-colors"
                            >
                                <Heart className="w-5 h-5" />
                            </button>
                            {product.isStartup && (
                                <div className="absolute top-4 left-4 bg-black/80 backdrop-blur text-white text-xs font-bold px-3 py-1 rounded-full border border-white/20">
                                    Startup
                                </div>
                            )}
                        </div>
                        
                        <div className="p-5 flex-1 flex flex-col">
                            <div className="mb-1 text-sm font-bold text-orange-600 dark:text-orange-400">{product.brand}</div>
                            <h3 className="font-display font-semibold text-lg text-slate-900 dark:text-white leading-tight mb-2 line-clamp-2">{product.name}</h3>
                            
                            <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
                                <div>
                                    <span className="text-xl font-bold text-slate-900 dark:text-white">₹{product.price.toLocaleString()}</span>
                                    {product.originalPrice && (
                                        <span className="text-sm text-slate-400 line-through ml-2">₹{product.originalPrice.toLocaleString()}</span>
                                    )}
                                </div>
                                <button 
                                    onClick={() => addToCart(product)}
                                    className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 p-3 rounded-xl hover:scale-105 active:scale-95 transition-all"
                                >
                                    <ShoppingCart className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            
            {/* Pagination Mock */}
            <div className="flex justify-center mt-12 gap-2">
                {[1, 2, 3].map(page => (
                    <button key={page} className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold transition-colors ${page === 1 ? 'bg-orange-600 text-white' : 'bg-slate-100 dark:bg-slate-800 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
                        {page}
                    </button>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};