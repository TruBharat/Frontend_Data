import React from 'react';
import { ShoppingBag, X, MoveRight } from 'lucide-react';
import { Product } from '../types';

interface WishlistProps {
  items: Product[];
  removeFromWishlist: (id: string) => void;
  moveToCart: (product: Product) => void;
}

export const Wishlist: React.FC<WishlistProps> = ({ items, removeFromWishlist, moveToCart }) => {
  if (items.length === 0) {
    return (
        <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-6">
                <HeartBroken className="w-10 h-10 text-slate-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2 dark:text-white">Your Wishlist is Empty</h2>
            <p className="text-slate-500 mb-8 max-w-md">Looks like you haven't saved any items yet. Explore our Indian collections and find something you love.</p>
        </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
            <h2 className="text-3xl font-display font-bold text-slate-900 dark:text-white">My Wishlist</h2>
            <p className="text-slate-500">You have {items.length} items saved</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((item) => (
            <div key={item.id} className="bg-white dark:bg-slate-900 rounded-[1.5rem] border border-slate-200 dark:border-slate-800 overflow-hidden relative group">
                <button 
                    onClick={() => removeFromWishlist(item.id)}
                    className="absolute top-3 right-3 z-10 w-8 h-8 bg-black/50 backdrop-blur rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors"
                >
                    <X className="w-4 h-4" />
                </button>
                
                <div className="aspect-square overflow-hidden">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                
                <div className="p-4">
                    <p className="text-xs font-bold text-orange-600 uppercase mb-1">{item.brand}</p>
                    <h3 className="font-semibold text-slate-900 dark:text-white truncate mb-2">{item.name}</h3>
                    <p className="font-bold text-lg mb-4 dark:text-slate-200">₹{item.price.toLocaleString()}</p>
                    
                    <button 
                        onClick={() => moveToCart(item)}
                        className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-colors"
                    >
                        Move to Cart
                    </button>
                </div>
            </div>
        ))}
      </div>
    </div>
  );
};

const HeartBroken = ({className}: {className?: string}) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
        <line x1="12" y1="13" x2="12" y2="13.01"/>
        <path d="m12 13 4-4"/>
        <path d="m12 13-4-4"/>
    </svg>
)
