import React from 'react';
import { Star, Quote } from 'lucide-react';

export const Testimonials = () => {
    const reviews = [
        { name: "Aarav K.", role: "Fashion Enthusiast", text: "Finally a place where I can find cool drip from local brands without sifting through junk. TruBharat is a vibe! 🔥", rating: 5, img: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=100" },
        { name: "Sanya M.", role: "Tech Geek", text: "Got my boAt headphones delivered in 2 hours. The startup section is honestly a goldmine for unique gadgets.", rating: 5, img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100" },
        { name: "Rohan D.", role: "Sustainable Shopper", text: "Love that I can filter by 'Startup' and support small Indian businesses. The bamboo products are amazing.", rating: 4, img: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100" },
    ];

    return (
        <section className="py-20 bg-white dark:bg-slate-950 px-4">
            <div className="max-w-7xl mx-auto">
                <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
                    <div>
                        <h2 className="text-4xl font-display font-bold text-slate-900 dark:text-white">Gen-Z Reviews</h2>
                        <p className="text-slate-500 mt-2">What the new generation says about us</p>
                    </div>
                    <div className="flex gap-2">
                        <div className="px-4 py-2 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-full text-sm font-bold">
                            4.8/5 Rating
                        </div>
                        <div className="px-4 py-2 bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 rounded-full text-sm font-bold">
                            10k+ Reviews
                        </div>
                    </div>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                    {reviews.map((review, idx) => (
                        <div key={idx} className="bg-slate-50 dark:bg-slate-900 p-8 rounded-[2rem] relative hover:shadow-xl transition-shadow border border-slate-100 dark:border-slate-800">
                            <Quote className="absolute top-8 right-8 w-10 h-10 text-orange-200 dark:text-slate-800" />
                            
                            <div className="flex items-center gap-4 mb-6">
                                <img src={review.img} alt={review.name} className="w-14 h-14 rounded-full object-cover border-2 border-white dark:border-slate-700 shadow-md" />
                                <div>
                                    <h4 className="font-bold text-slate-900 dark:text-white">{review.name}</h4>
                                    <p className="text-xs text-slate-500">{review.role}</p>
                                </div>
                            </div>
                            
                            <div className="flex gap-1 mb-4">
                                {[...Array(5)].map((_, i) => (
                                    <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'fill-orange-400 text-orange-400' : 'text-slate-300'}`} />
                                ))}
                            </div>

                            <p className="text-slate-700 dark:text-slate-300 leading-relaxed italic">"{review.text}"</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};
