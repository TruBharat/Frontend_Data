import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateAssistantResponse = async (userMessage: string, context?: string) => {
  if (!process.env.API_KEY) {
    return "I'm sorry, I'm currently offline (API Key Missing). Please explore our products manually!";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userMessage,
      config: {
        systemInstruction: `You are 'BharatBot', the helpful AI shopping assistant for TruBharat, an e-commerce platform dedicated to Indian brands.
        Your goal is to help users find products, understand the history of Indian brands (like Titan, FabIndia, etc.), and provide styling tips.
        Keep your tone friendly, Gen-Z appropriate (use emojis occasionally, keep it snappy), and very patriotic about "Made in India".
        
        If the user asks for product recommendations, use general knowledge about Indian fashion and tech to suggest types of items they might like.
        
        Current Context: ${context || 'Browsing the home page'}
        `,
      }
    });
    
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Oops! My brain froze for a second. Can you ask that again?";
  }
};