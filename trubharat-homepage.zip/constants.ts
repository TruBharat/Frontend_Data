
import { Product, Brand, Category } from './types';

export const BRANDS: Brand[] = [
  { id: '1', name: 'Titan', logo: 'https://shorturl.at/JWeDy', founded: '1984' },
  { id: '2', name: 'Mamaearth', logo: 'https://shorturl.at/VpAtS', founded: '2016' },
  { id: '3', name: 'boAt', logo: 'https://shorturl.at/gQlDu', founded: '2014' },
  { id: '6', name: 'Nykaa', logo: 'https://tinyurl.com/yy2k82jn', founded: '2012' },
  { id: '7', name: 'Noise', logo: 'https://tinyurl.com/dtxy323w', founded: '2018' },
  { id: '8', name: 'Zomato', logo: 'https://tinyurl.com/2pmmz47m', founded: '2008' },
  { id: '9', name: 'Swiggy', logo: 'https://tinyurl.com/msfuv2pf', founded: '2014' },
  { id: '10', name: 'Myntra', logo: 'https://tinyurl.com/2se3hctj', founded: '2007' },
  { id: '11', name: 'Flipkart', logo: 'https://tinyurl.com/2dpz9d6v', founded: '2007' },
  { id: '12', name: 'Lenskart', logo: 'https://tinyurl.com/ywzh3xrt', founded: '2010' },
  { id: '13', name: 'Bira91', logo: 'https://tinyurl.com/33xjjytr', founded: '2015' },
  { id: '14', name: 'Amul', logo: 'https://tinyurl.com/5xjjyt72', founded: '1946' },
];

export const CATEGORIES: Category[] = [
  { id: '1', name: 'Fashion', icon: 'shirt' },
  { id: '2', name: 'Electronics', icon: 'headphones' },
  { id: '3', name: 'Home & Kitchen', icon: 'home' },
  { id: '4', name: 'Beauty & Care', icon: 'sparkles' },
  { id: '5', name: 'Grocery & Essentials', icon: 'apple' },
  { id: '6', name: 'Startup Zone', icon: 'rocket' },
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Cotton Kurtas',
    brand: 'FabIndia',
    price: 2499,
    originalPrice: 3999,
    image: 'https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=600',
    category: 'Fashion',
    rating: 4.5,
    reviews: 120,
    colors: ['#f5f5dc', '#ffd700']
  },
  {
    id: '2',
    name: 'Rockerz 450',
    brand: 'boAt',
    price: 1499,
    originalPrice: 2999,
    image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&q=80&w=600',
    category: 'Electronics',
    rating: 4.2,
    reviews: 3500,
    colors: ['#000000', '#ff0000']
  },
  {
    id: '3',
    name: 'Onion Hair Oil',
    brand: 'Mamaearth',
    price: 399,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=600',
    category: 'Beauty',
    rating: 4.6,
    reviews: 900
  },
  {
    id: '4',
    name: 'ColorFit Pro',
    brand: 'Noise',
    price: 2499,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=600',
    category: 'Electronics',
    rating: 4.8,
    reviews: 85
  },
  {
    id: 'trending1',
    name: 'Fastrack Reflex',
    brand: 'Fastrack',
    price: 1195,
    image: 'https://imgs.search.brave.com/VOQ_DGJ9FartTJbmRoNSVEuTaHLxyPPDDP3e9QO3nHw/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL0kv/NDFLa0VheVdmaEwu/anBn',
    category: 'Fashion',
    rating: 4.5,
    reviews: 100
  },
  {
    id: 'trending2',
    name: 'Wheatgrass Juice',
    brand: 'Kapiva',
    price: 449,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=600',
    category: 'Grocery',
    rating: 4.3,
    reviews: 50
  },
  {
    id: 'trending3',
    name: 'Kumkumadi Face Oil',
    brand: 'Ayuga',
    price: 799,
    image: 'https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?auto=format&fit=crop&q=80&w=600',
    category: 'Beauty',
    rating: 4.7,
    reviews: 200
  }
];
