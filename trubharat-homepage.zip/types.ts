export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  isStartup?: boolean;
  colors?: string[];
}

export interface Brand {
  id: string;
  name: string;
  logo: string;
  founded?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export enum PageView {
  HOME = 'HOME',
  SHOP = 'SHOP',
  WISHLIST = 'WISHLIST',
}

export type Category = {
  id: string;
  name: string;
  icon: string; // URL or component key
}