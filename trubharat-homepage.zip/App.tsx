import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { ProductGrid } from './components/ProductGrid';
import { Wishlist } from './components/Wishlist';
import { Testimonials } from './components/Testimonials';
import { Footer } from './components/Footer';
import { ChatBot } from './components/ChatBot';
import { Product, PageView } from './types';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [pageView, setPageView] = useState<PageView>(PageView.HOME);
  const [cart, setCart] = useState<Product[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);

  // Toggle Dark Mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(!darkMode);

  // Cart & Wishlist Logic
  const addToCart = (product: Product) => {
    setCart([...cart, product]);
    alert(`Added ${product.name} to cart!`);
  };

  const addToWishlist = (product: Product) => {
    if (!wishlist.find(i => i.id === product.id)) {
      setWishlist([...wishlist, product]);
    }
  };

  const removeFromWishlist = (id: string) => {
    setWishlist(wishlist.filter(i => i.id !== id));
  };

  const moveToCart = (product: Product) => {
      removeFromWishlist(product.id);
      addToCart(product);
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans selection:bg-orange-200 dark:selection:bg-orange-900 transition-colors duration-300">
      <Navbar 
        darkMode={darkMode} 
        toggleDarkMode={toggleDarkMode} 
        cartCount={cart.length}
        wishlistCount={wishlist.length}
        setPageView={setPageView}
      />

      <main>
        {pageView === PageView.HOME && (
          <div className="animate-in fade-in duration-500">
            <Hero setPageView={setPageView} />
            <Features setPageView={setPageView} />
            <Testimonials />
          </div>
        )}

        {pageView === PageView.SHOP && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <ProductGrid 
                addToCart={addToCart} 
                addToWishlist={addToWishlist} 
            />
          </div>
        )}

        {pageView === PageView.WISHLIST && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Wishlist 
                items={wishlist} 
                removeFromWishlist={removeFromWishlist} 
                moveToCart={moveToCart}
            />
          </div>
        )}
      </main>

      <Footer />
      <ChatBot />
    </div>
  );
}

export default App;